// =========================================================
// VARIÁVEIS
// =========================================================

let port = null;
let reader = null;
let writer = null;

let buffer = "";


// =========================================================
// ELEMENTOS HTML
// =========================================================

const connectButton =
    document.getElementById("connectButton");

const connectionDot =
    document.getElementById("connectionDot");

const connectionText =
    document.getElementById("connectionText");

const statusCircle =
    document.getElementById("statusCircle");

const statusText =
    document.getElementById("statusText");

const serialMonitor =
    document.getElementById("serialMonitor");

const warning =
    document.getElementById("warning");

const onButton =
    document.getElementById("onButton");

const offButton =
    document.getElementById("offButton");

const clearButton =
    document.getElementById("clearButton");


// =========================================================
// VERIFICAR SUPORTE AO WEB SERIAL
// =========================================================

if (!("serial" in navigator)) {

    warning.style.display = "block";

    adicionarSerial(
        "ERRO: Web Serial não é suportado neste navegador."
    );
}


// =========================================================
// BOTÃO CONECTAR
// =========================================================

connectButton.addEventListener(
    "click",
    connectSerial
);


// =========================================================
// BOTÃO LIGAR
// =========================================================

onButton.addEventListener(
    "click",
    ligarBomba
);


// =========================================================
// BOTÃO DESLIGAR
// =========================================================

offButton.addEventListener(
    "click",
    desligarBomba
);


// =========================================================
// BOTÃO LIMPAR
// =========================================================

clearButton.addEventListener(
    "click",
    limparMonitor
);


// =========================================================
// CONECTAR AO ARDUINO
// =========================================================

async function connectSerial() {

    try {

        adicionarSerial(
            "Solicitando conexão com o Arduino..."
        );


        // Abre janela para selecionar a porta

        port =
            await navigator.serial.requestPort();


        // Abre a porta em 9600 baud

        await port.open({
            baudRate: 9600
        });


        // Atualiza interface

        connectionDot
            .classList
            .add("connected");

        connectionText.textContent =
            "Arduino conectado";

        connectButton.textContent =
            "✅ Arduino conectado";


        adicionarSerial(
            "Arduino conectado com sucesso."
        );


        // Cria escritor da porta

        writer =
            port.writable.getWriter();


        // Começa a leitura

        readSerial();

    }

    catch (error) {

        console.error(error);

        adicionarSerial(
            "ERRO: Não foi possível conectar ao Arduino."
        );

    }
}


// =========================================================
// LER PORTA SERIAL
// =========================================================

async function readSerial() {

    reader =
        port.readable.getReader();


    const decoder =
        new TextDecoder();


    try {

        while (true) {

            const {
                value,
                done
            } = await reader.read();


            if (done) {
                break;
            }


            if (!value) {
                continue;
            }


            // Converte os bytes recebidos para texto

            buffer +=
                decoder.decode(value);


            // Divide por linhas

            const linhas =
                buffer.split("\n");


            // Guarda a última linha incompleta

            buffer =
                linhas.pop();


            // Processa as linhas completas

            for (let linha of linhas) {

                linha =
                    linha.trim();


                if (linha.length === 0) {
                    continue;
                }


                // Mostra no monitor

                adicionarSerial(linha);


                // Analisa a mensagem

                interpretarMensagem(linha);
            }

        }

    }

    catch (error) {

        console.error(error);

        adicionarSerial(
            "ERRO: conexão serial encerrada."
        );

    }

    finally {

        reader.releaseLock();

    }
}


// =========================================================
// INTERPRETAR MENSAGEM DO ARDUINO
// =========================================================

function interpretarMensagem(mensagem) {

    if (
        mensagem.includes(
            "Bomba: LIGADA"
        )
    ) {

        atualizarStatus(true);

    }


    if (
        mensagem.includes(
            "Bomba: DESLIGADA"
        )
    ) {

        atualizarStatus(false);

    }
}


// =========================================================
// ATUALIZAR STATUS
// =========================================================

function atualizarStatus(ligada) {

    if (ligada) {

        statusCircle
            .classList
            .add("ligada");

        statusText.textContent =
            "BOMBA LIGADA";

    }

    else {

        statusCircle
            .classList
            .remove("ligada");

        statusText.textContent =
            "BOMBA DESLIGADA";

    }
}


// =========================================================
// ENVIAR COMANDO PARA O ARDUINO
// =========================================================

async function enviarComando(comando) {

    if (!port || !writer) {

        adicionarSerial(
            "ERRO: Arduino não está conectado."
        );

        return;
    }


    try {

        const encoder =
            new TextEncoder();


        await writer.write(
            encoder.encode(comando)
        );


        adicionarSerial(
            ">> Enviado: " + comando
        );

    }

    catch (error) {

        console.error(error);

        adicionarSerial(
            "ERRO ao enviar comando."
        );

    }
}


// =========================================================
// LIGAR BOMBA
// =========================================================

async function ligarBomba() {

    await enviarComando("1");

}


// =========================================================
// DESLIGAR BOMBA
// =========================================================

async function desligarBomba() {

    await enviarComando("0");

}


// =========================================================
// MONITOR SERIAL
// =========================================================

function adicionarSerial(mensagem) {

    const hora =
        new Date().toLocaleTimeString();


    serialMonitor.textContent +=
        `[${hora}] ${mensagem}\n`;


    // Scroll automático para o final

    serialMonitor.scrollTop =
        serialMonitor.scrollHeight;
}


// =========================================================
// LIMPAR MONITOR
// =========================================================

function limparMonitor() {

    serialMonitor.textContent = "";

}
